import * as React from 'react';
import {Text,View,TouchableOpacity,StyleSheet}  from 'react-native';
import {Audio} from 'expo-av';

export default class PhonicSoundButton extends React.Component{
  playSound = async soundChunk => {
    var soundLink = "https://s3-whitehatjrcontent.whjr.online/phones/" + soundChunk + ".mp3"
    await Audio.Sound.createAsync(
      {
      uri: soundLink
      },
      {
        shouldPlay: true,
        

      }
    
    )


  }
  render(){

    return(
      <TouchableOpacity  style = {styles.wordChunkButton} onPress = {() => {
        this.playSound(this.props.soundChunk)
      }}>
        <Text style = {styles.displayText}> 
          {this.props.wordChunk}
        </Text>
      </TouchableOpacity>
    )
  }

}
const styles = StyleSheet.create({
  displayText: {
    textAlign: "center",
    color: "blue",
    fontSize: 25,
    fontWeight: "bold",

  },
  wordChunkButton: {
    width: "60%",
    height: 50,
    justifyContent: "50%",
    alignItems: "center",
    alinghtSelf: "center",
    borderRadius: 10,
    margin: 5,
    backgroundColor: "light_blue",
  },

})