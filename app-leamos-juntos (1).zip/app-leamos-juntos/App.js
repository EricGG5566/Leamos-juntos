import * as React from 'react';
import {Text,View,StyleSheet,TextInput,TouchableOpacity, Image} from 'react-native';
import {Header} from 'react-native-elements';
import db from "./localDB";
import PhonicSoundButton from './components/PhonicSoundButton';

export default class App extends React.Component{
   constructor(){
     super();
     this.state = {
       text: "",
       chunks:[],
      phonicSounds: [],

     }
   }
    render(){

      return(
        <View style ={styles.container}>
         <Header 
          backgroundColor = {"purple"} 
          centerComponent = {{
            text: "¡LEAMOS JUNTOS!", style: {fontSize: 20, color:"yellow"}
          }}>
         </Header>
          <Image style={styles.imageStyle} 
        
          source = {require("./letrascolores.jpg")}>
          </Image>
         <TextInput style = {styles.inputBox} onChangeText = {text => {
           this.setState({text: text})
            }}  value = {this.state.text} > 
         </TextInput>
         <Text styles={styles.buttonText}>{this.state.displayText}</Text>
         <TouchableOpacity style={styles.goButton} 
          onPress = {()=>{

            this.setState({chunks: db[this.state.text].chunks})
             this.setState({phonicSounds: db[this.state.text].phones})
          }}> 

          <Text style ={styles.buttonText}>
            EMPEZAR
         </Text>
        </TouchableOpacity>
        <View>
        {this.state.chunks.map((item,index ) => {
         return(
          <PhonicSoundButton 
           wordChunk ={this.state.chunks[index]}
           soundChunk ={this.state.phonicSounds[index]}
          >
          </PhonicSoundButton>
         )
         
        })}
       </View>
        </View>
      )//Fin return
    }//Fin render
}//Fin App
    
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "light_blue",

    }, //Fin Container
    inputBox: {
      marginTop: 30,
      width: "70%",
      alignSelf: "center",
      height: 30,
      TextAling: "center",
      borderWidth: 5,
      borderColor: "yellow",
      fontSize: 15,
      color: "black",
      fontWeight: "bold",
    },//Fin inputBox
      goButton: {
        width: "70%",
        height: 70,
        alignSelf: "center",
        margin: 30,
        fontSize: 20,
        fontWeight: "bold",
      
     },//final de gobutton
     buttonText: {
       textAling: "center",
       fontSize: 50,
       color: "black",
     },//fin buttontext
      imageStyle: {
      width: 300,
      height: 300,
      marginTop: 40,
      marginLeft: 30,
      },
  
  }) //Fin StyleSheet

    

    


